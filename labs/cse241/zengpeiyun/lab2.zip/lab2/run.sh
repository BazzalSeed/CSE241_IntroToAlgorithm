#!/bin/sh

java -cp bin lab2.Lab2 $@